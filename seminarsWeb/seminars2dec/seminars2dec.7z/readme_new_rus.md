1) https://www.w3schools.com/php/phptryit.asp?filename=tryphp_compiler
2) MySQL Workbench my.ini