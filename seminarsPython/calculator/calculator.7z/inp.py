#
def myOutput(a):
    print("Hello World")
    print(a)
    
def myInput():
    print("Please enter your number of the")
    return input()
